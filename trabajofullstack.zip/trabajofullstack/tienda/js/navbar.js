function updateNavbarCounter() {
  const cartData = localStorage.getItem("app_cart");
  const cart = cartData ? JSON.parse(cartData) : [];
  const totalItems = cart.reduce((acc, current) => acc + current.cantidad, 0);

  const cartCounterElem = document.getElementById("cart-counter");
  if (cartCounterElem) {
    cartCounterElem.textContent = `Cart (${totalItems})`;
  }
}

document.addEventListener("DOMContentLoaded", updateNavbarCounter);