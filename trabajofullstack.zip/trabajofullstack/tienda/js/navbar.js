function updateNavbarCounter() {
  const cart = JSON.parse(localStorage.getItem("app_cart")) || [];
  const totalCount = cart.reduce((acc, item) => acc + item.cantidad, 0);
  const counterElem = document.getElementById("cart-counter");
  if (counterElem) {
    counterElem.textContent = `Cart (${totalCount})`;
  }
}

document.addEventListener("DOMContentLoaded", updateNavbarCounter);