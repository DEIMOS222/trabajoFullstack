let currentDiscount = 0;

function getCart() {
  const data = localStorage.getItem("app_cart");
  return data ? JSON.parse(data) : [];
}

function saveCart(cart) {
  localStorage.setItem("app_cart", JSON.stringify(cart));
  if (typeof updateNavbarCounter === "function") {
    updateNavbarCounter();
  }
}

function addToCart(producto, cantidad = 1) {
  const cart = getCart();
  const index = cart.findIndex(item => item.id === producto.id);

  if (index !== -1) {
    cart[index].cantidad += cantidad;
  } else {
    cart.push({
      id: producto.id,
      nombre: producto.nombre,
      precio: producto.precio,
      cantidad: cantidad
    });
  }

  saveCart(cart);
  alert(`Agregado: ${cantidad}x ${producto.nombre}`);
}

function changeQuantity(id, delta) {
  let cart = getCart();
  const item = cart.find(i => i.id === id);
  if (!item) return;

  item.cantidad += delta;
  if (item.cantidad <= 0) {
    cart = cart.filter(i => i.id !== id);
  }

  saveCart(cart);
  renderCartView();
}

function renderCartView() {
  const cartContainer = document.getElementById("cart-container");
  const cartTotal = document.getElementById("cart-total");
  if (!cartContainer || !cartTotal) return;

  const cart = getCart();

  if (cart.length === 0) {
    cartContainer.innerHTML = "<p>El carrito de compras esta actualmente vacio.</p>";
    cartTotal.textContent = "$0";
    return;
  }

  let subtotalGeneral = 0;
  cartContainer.innerHTML = cart.map(item => {
    const itemSubtotal = item.precio * item.cantidad;
    subtotalGeneral += itemSubtotal;
    return `
      <div class="cart-item">
        <div class="cart-item-info">
          <h4>${item.nombre}</h4>
          <p>$${item.precio.toLocaleString("es-CL")} c/u</p>
        </div>
        <div class="cart-item-ctrls">
          <button type="button" onclick="changeQuantity('${item.id}', -1)">-</button>
          <span>${item.cantidad}</span>
          <button type="button" onclick="changeQuantity('${item.id}', 1)">+</button>
        </div>
        <div class="cart-item-subtotal">
          <strong>$${itemSubtotal.toLocaleString("es-CL")}</strong>
        </div>
      </div>
    `;
  }).join("");

  const finalTotal = Math.round(subtotalGeneral * (1 - currentDiscount));
  cartTotal.textContent = `$${finalTotal.toLocaleString("es-CL")}`;
}

document.addEventListener("DOMContentLoaded", () => {
  renderCartView();

  const btnCoupon = document.getElementById("btn-coupon");
  const couponInput = document.getElementById("coupon-input");
  const couponMsg = document.getElementById("coupon-msg");

  if (btnCoupon && couponInput) {
    btnCoupon.addEventListener("click", () => {
      const code = couponInput.value.trim().toUpperCase();
      if (code === "DUOC10") {
        currentDiscount = 0.10;
        couponMsg.style.color = "#198754";
        couponMsg.textContent = "¡Cupon aplicado! 10% de descuento.";
      } else {
        currentDiscount = 0;
        couponMsg.style.color = "#dc3545";
        couponMsg.textContent = "Cupon no reconocido.";
      }
      renderCartView();
    });
  }

  const btnCheckout = document.getElementById("btn-checkout");
  if (btnCheckout) {
    btnCheckout.addEventListener("click", () => {
      const cart = getCart();
      if (cart.length === 0) {
        alert("Agregue productos antes de realizar el pago.");
      } else {
        alert("Redirigiendo a pasarela de pago...");
      }
    });
  }
});