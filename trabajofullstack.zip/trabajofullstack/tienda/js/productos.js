document.addEventListener("DOMContentLoaded", () => {
  const productos = getStoredProducts();

  // Catálogo completo (productos.html)
  const catalogoGrid = document.getElementById("catalogo-grid");
  if (catalogoGrid) {
    catalogoGrid.innerHTML = productos.map(prod => `
      <div class="card">
        <div class="card-img-container">
          <img src="${prod.imagen}" alt="${prod.nombre}" class="img-fluid">
        </div>
        <h3>${prod.nombre}</h3>
        <p><strong>$${prod.precio.toLocaleString("es-CL")}</strong></p>
        <a href="detalle-producto.html?id=${prod.id}" class="btn btn-primary">Ver detalle</a>
      </div>
    `).join("");
  }

  // Destacados de Portada (index.html)
  const destacadosGrid = document.getElementById("destacados-grid");
  if (destacadosGrid) {
    destacadosGrid.innerHTML = productos.slice(0, 4).map(prod => `
      <div class="card">
        <div class="card-img-container">
          <img src="${prod.imagen}" alt="${prod.nombre}" class="img-fluid">
        </div>
        <h3>${prod.nombre}</h3>
        <p><strong>$${prod.precio.toLocaleString("es-CL")}</strong></p>
        <a href="detalle-producto.html?id=${prod.id}" class="btn">Ver producto</a>
      </div>
    `).join("");
  }

  // Ficha Detallada (detalle-producto.html)
  const detailTitle = document.getElementById("detail-title");
  if (detailTitle) {
    const urlParams = new URLSearchParams(window.location.search);
    const selectedId = urlParams.get("id");
    const currentProduct = productos.find(p => p.id === selectedId) || productos[0];

    if (currentProduct) {
      detailTitle.textContent = currentProduct.nombre;
      document.getElementById("detail-price").textContent = `$${currentProduct.precio.toLocaleString("es-CL")}`;
      document.getElementById("detail-desc").textContent = currentProduct.descripcion;
      document.getElementById("breadcrumb").textContent = `Home > Componentes > ${currentProduct.nombre}`;
      
      const mainImg = document.getElementById("main-product-img");
      if (mainImg) {
        mainImg.src = currentProduct.imagen;
        mainImg.alt = currentProduct.nombre;
      }

      document.getElementById("btn-add-cart").addEventListener("click", () => {
        const qty = parseInt(document.getElementById("input-qty").value, 10) || 1;
        if (qty > 0) {
          addToCart(currentProduct, qty);
        }
      });

      const relatedGrid = document.getElementById("related-grid");
      if (relatedGrid) {
        relatedGrid.innerHTML = productos
          .filter(p => p.id !== currentProduct.id)
          .slice(0, 3)
          .map(prod => `
            <div class="card">
              <div class="card-img-container">
                <img src="${prod.imagen}" alt="${prod.nombre}" class="img-fluid">
              </div>
              <h4>${prod.nombre}</h4>
              <p>$${prod.precio.toLocaleString("es-CL")}</p>
              <a href="detalle-producto.html?id=${prod.id}" class="btn">Revisar</a>
            </div>
          `).join("");
      }
    }
  }
});