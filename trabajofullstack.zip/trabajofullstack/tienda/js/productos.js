document.addEventListener("DOMContentLoaded", () => {
  const productos = getStoredProducts();

  // 1. Render para catálogo completo
  const catalogoGrid = document.getElementById("catalogo-grid");
  if (catalogoGrid) {
    catalogoGrid.innerHTML = productos.map(prod => `
      <div class="card">
        <div class="card-img-placeholder">[ Imagen ]</div>
        <h3>${prod.nombre}</h3>
        <p>$${prod.precio.toLocaleString("es-CL")}</p>
        <a href="detalle-producto.html?id=${prod.id}" class="btn">Ver detalle</a>
      </div>
    `).join("");
  }

  // 2. Render para home (muestra hasta 4 destacados)
  const destacadosGrid = document.getElementById("destacados-grid");
  if (destacadosGrid) {
    destacadosGrid.innerHTML = productos.slice(0, 4).map(prod => `
      <div class="card">
        <div class="card-img-placeholder">[ Imagen ]</div>
        <h3>${prod.nombre}</h3>
        <p>$${prod.precio.toLocaleString("es-CL")}</p>
        <a href="detalle-producto.html?id=${prod.id}" class="btn">Ver producto</a>
      </div>
    `).join("");
  }

  // 3. Render para detalle del producto
  const detailTitle = document.getElementById("detail-title");
  if (detailTitle) {
    const params = new URLSearchParams(window.location.search);
    const prodId = params.get("id");
    const item = productos.find(p => p.id === prodId);

    if (item) {
      detailTitle.textContent = item.nombre;
      document.getElementById("detail-price").textContent = `$${item.precio.toLocaleString("es-CL")}`;
      document.getElementById("detail-desc").textContent = item.descripcion;
      document.getElementById("breadcrumb").textContent = `Home > Productos > ${item.nombre}`;

      document.getElementById("btn-add-cart").addEventListener("click", () => {
        const qty = parseInt(document.getElementById("input-qty").value, 10) || 1;
        addToCart(item, qty);
      });
    } else {
      detailTitle.textContent = "Producto no encontrado";
    }
  }
});