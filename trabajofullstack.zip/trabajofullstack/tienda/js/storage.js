const initialProducts = [
  { id: "PROD-01", nombre: "Producto Alfa", precio: 8000, stock: 15, descripcion: "Descripcion detallada del Producto Alfa." },
  { id: "PROD-02", nombre: "Producto Beta", precio: 6000, stock: 22, descripcion: "Descripcion detallada del Producto Beta." },
  { id: "PROD-03", nombre: "Producto Gamma", precio: 10000, stock: 5, descripcion: "Descripcion detallada del Producto Gamma." },
  { id: "PROD-04", nombre: "Producto Delta", precio: 15000, stock: 8, descripcion: "Descripcion detallada del Producto Delta." }
];

if (!localStorage.getItem("app_productos")) {
  localStorage.setItem("app_productos", JSON.stringify(initialProducts));
}

function getStoredProducts() {
  return JSON.parse(localStorage.getItem("app_productos")) || [];
}