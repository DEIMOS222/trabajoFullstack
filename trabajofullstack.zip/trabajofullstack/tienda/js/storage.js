const defaultTechCatalog = [
  {
    id: "TECH-01",
    nombre: "Kit Refrigeracion Liquida AIO 240mm ARGB",
    precio: 89990,
    stock: 14,
    descripcion: "Sistema todo en uno con radiador dual de 240mm, bomba de bajo ruido con rodamientos cerámicos e iluminación ARGB sincronizable con la placa madre.",
    imagen: "https://images.unsplash.com/photo-1587202372634-32705e3bf49c?w=600&q=80"
  },
  {
    id: "TECH-02",
    nombre: "Placa Madre Gaming WiFi Chipset B650 ATX",
    precio: 164990,
    stock: 9,
    descripcion: "Diseño con 14+2 fases VRM reforzadas, disipadores integrados en ranuras M.2 PCIe 5.0 y conectividad LAN 2.5G con WiFi 6E.",
    imagen: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=600&q=80"
  },
  {
    id: "TECH-03",
    nombre: "Memoria RAM DDR5 32GB (2x16GB) 6000MHz",
    precio: 119990,
    stock: 20,
    descripcion: "Kit de memorias con perfil AMD EXPO e Intel XMP 3.0 para latencias ultra bajas y disipador termico de aluminio cepillado.",
    imagen: "https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=600&q=80"
  },
  {
    id: "TECH-04",
    nombre: "Unidad SSD NVMe M.2 1TB PCIe 4.0",
    precio: 74990,
    stock: 28,
    descripcion: "Velocidades de hasta 7400 MB/s de lectura y 6500 MB/s de escritura. Preparada para cargas masivas de datos y compilacion de proyectos.",
    imagen: "https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?w=600&q=80"
  }
];

if (!localStorage.getItem("app_productos")) {
  localStorage.setItem("app_productos", JSON.stringify(defaultTechCatalog));
}

function getStoredProducts() {
  const data = localStorage.getItem("app_productos");
  return data ? JSON.parse(data) : [];
}