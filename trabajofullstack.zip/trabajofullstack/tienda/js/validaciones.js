const datasetGeografico = [
  {
    region: "Region Metropolitana de Santiago",
    comunas: ["Santiago", "Providencia", "Las Condes", "La Florida", "Maipu", "Puente Alto"]
  },
  {
    region: "Region de la Araucania",
    comunas: ["Temuco", "Padre Las Casas", "Villarrica", "Pucon", "Angol"]
  },
  {
    region: "Region de ñuble",
    comunas: ["Chillan", "San Carlos", "Bulnes", "Coihueco"]
  }
];

function validarDominioCorreo(correo) {
  const patron = /^[a-zA-Z0-9._%+-]+@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/;
  return patron.test(correo.trim());
}

function validarRunChileno(rutString) {
  const limpio = rutString.replace(/[^0-9kK]/g, "").toUpperCase();
  if (limpio.length < 7 || limpio.length > 9) return false;

  const cuerpo = limpio.slice(0, -1);
  const dv = limpio.slice(-1);

  let suma = 0;
  let factor = 2;

  for (let i = cuerpo.length - 1; i >= 0; i--) {
    suma += factor * parseInt(cuerpo.charAt(i), 10);
    factor = factor < 7 ? factor + 1 : 2;
  }

  const residuo = 11 - (suma % 11);
  let dvEsperado = "";
  if (residuo === 11) dvEsperado = "0";
  else if (residuo === 10) dvEsperado = "K";
  else dvEsperado = residuo.toString();

  return dv === dvEsperado;
}

document.addEventListener("DOMContentLoaded", () => {
  // Cascada Región y Comuna (registro.html)
  const selectRegion = document.getElementById("reg-region");
  const selectComuna = document.getElementById("reg-comuna");

  if (selectRegion && selectComuna) {
    selectRegion.innerHTML = `<option value="">Seleccione region...</option>` +
      datasetGeografico.map(item => `<option value="${item.region}">${item.region}</option>`).join("");

    selectRegion.addEventListener("change", (e) => {
      const match = datasetGeografico.find(r => r.region === e.target.value);
      if (match) {
        selectComuna.innerHTML = `<option value="">Seleccione comuna...</option>` +
          match.comunas.map(c => `<option value="${c}">${c}</option>`).join("");
      } else {
        selectComuna.innerHTML = `<option value="">Seleccione comuna...</option>`;
      }
    });
  }

  // Validacion de Login
  const formLogin = document.getElementById("form-login");
  if (formLogin) {
    formLogin.addEventListener("submit", (e) => {
      e.preventDefault();
      let esValido = true;

      const email = document.getElementById("login-email").value.trim();
      const pass = document.getElementById("login-pass").value;
      const errEmail = document.getElementById("err-login-email");
      const errPass = document.getElementById("err-login-pass");

      errEmail.textContent = "";
      errPass.textContent = "";

      if (!validarDominioCorreo(email)) {
        errEmail.textContent = "Solo correos @duoc.cl, @profesor.duoc.cl o @gmail.com.";
        esValido = false;
      }

      if (pass.length < 4 || pass.length > 10) {
        errPass.textContent = "La contraseña debe tener de 4 a 10 caracteres.";
        esValido = false;
      }

      if (esValido) {
        alert("Inicio de sesion correcto.");
        window.location.href = "index.html";
      }
    });
  }

  // Validacion de Registro
  const formReg = document.getElementById("form-registro");
  if (formReg) {
    formReg.addEventListener("submit", (e) => {
      e.preventDefault();
      let esValido = true;

      const run = document.getElementById("reg-run").value.trim();
      const nombre = document.getElementById("reg-nombre").value.trim();
      const apellidos = document.getElementById("reg-apellidos").value.trim();
      const email = document.getElementById("reg-email").value.trim();
      const pass = document.getElementById("reg-pass").value;
      const passConf = document.getElementById("reg-pass-confirm").value;
      const direccion = document.getElementById("reg-direccion").value.trim();
      const region = selectRegion ? selectRegion.value : "";
      const comuna = selectComuna ? selectComuna.value : "";

      document.querySelectorAll(".error-msg").forEach(span => span.textContent = "");

      if (!validarRunChileno(run)) {
        document.getElementById("err-reg-run").textContent = "RUN invalido. Formato sin puntos ni guion (ej: 19011022K).";
        esValido = false;
      }

      if (!nombre || nombre.length > 50) {
        document.getElementById("err-reg-nombre").textContent = "Nombre requerido (max. 50 caracteres).";
        esValido = false;
      }

      if (!apellidos || apellidos.length > 100) {
        document.getElementById("err-reg-apellidos").textContent = "Apellidos requeridos (max. 100 caracteres).";
        esValido = false;
      }

      if (!validarDominioCorreo(email)) {
        document.getElementById("err-reg-email").textContent = "Solo correos @duoc.cl, @profesor.duoc.cl o @gmail.com.";
        esValido = false;
      }

      if (pass.length < 4 || pass.length > 10) {
        document.getElementById("err-reg-pass").textContent = "Contraseña de 4 a 10 caracteres.";
        esValido = false;
      } else if (pass !== passConf) {
        document.getElementById("err-reg-pass-confirm").textContent = "Las contraseñas no coinciden.";
        esValido = false;
      }

      if (!direccion || direccion.length > 300) {
        document.getElementById("err-reg-direccion").textContent = "Direccion requerida (max. 300 caracteres).";
        esValido = false;
      }

      if (!region) {
        document.getElementById("err-reg-region").textContent = "Seleccione una region.";
        esValido = false;
      }

      if (!comuna) {
        document.getElementById("err-reg-comuna").textContent = "Seleccione una comuna.";
        esValido = false;
      }

      if (esValido) {
        alert("Usuario registrado con exito.");
        window.location.href = "login.html";
      }
    });
  }

  // Validación de Contacto
  const formCont = document.getElementById("form-contacto");
  if (formCont) {
    formCont.addEventListener("submit", (e) => {
      e.preventDefault();
      let esValido = true;

      const nombre = document.getElementById("cont-nombre").value.trim();
      const email = document.getElementById("cont-email").value.trim();
      const mensaje = document.getElementById("cont-mensaje").value.trim();

      const errNombre = document.getElementById("err-cont-nombre");
      const errEmail = document.getElementById("err-cont-email");
      const errMensaje = document.getElementById("err-cont-mensaje");

      errNombre.textContent = "";
      errEmail.textContent = "";
      errMensaje.textContent = "";

      if (!nombre || nombre.length > 100) {
        errNombre.textContent = "El nombre es obligatorio (max. 100 caracteres).";
        esValido = false;
      }

      if (!validarDominioCorreo(email)) {
        errEmail.textContent = "Solo correos @duoc.cl, @profesor.duoc.cl o @gmail.com.";
        esValido = false;
      }

      if (!mensaje || mensaje.length > 500) {
        errMensaje.textContent = "El mensaje es obligatorio (max. 500 caracteres).";
        esValido = false;
      }

      if (esValido) {
        alert("Consulta enviada con exito.");
        formCont.reset();
      }
    });
  }
});