// Arreglo de regiones y comunas
const regionesComunas = [
  { region: "Region Metropolitana de Santiago", comunas: ["Santiago", "Providencia", "La Florida", "Maipu"] },
  { region: "Region de la Araucania", comunas: ["Temuco", "Padre Las Casas", "Villarrica"] },
  { region: "Region de Ñuble", comunas: ["Chillan", "San Carlos", "Bulnes"] }
];

function isValidEmailDomain(email) {
  const regex = /^[a-zA-Z0-9._%+-]+@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/;
  return regex.test(email.trim());
}

document.addEventListener("DOMContentLoaded", () => {
  // 1. Selector Región / Comuna en Registro
  const selectReg = document.getElementById("reg-region");
  const selectCom = document.getElementById("reg-comuna");

  if (selectReg && selectCom) {
    selectReg.innerHTML = `<option value="">Seleccione región...</option>` +
      regionesComunas.map(r => `<option value="${r.region}">${r.region}</option>`).join("");

    selectReg.addEventListener("change", (e) => {
      const selected = regionesComunas.find(r => r.region === e.target.value);
      if (selected) {
        selectCom.innerHTML = `<option value="">Seleccione comuna...</option>` +
          selected.comunas.map(c => `<option value="${c}">${c}</option>`).join("");
      } else {
        selectCom.innerHTML = `<option value="">Seleccione comuna...</option>`;
      }
    });
  }

  // 2. Validación Login
  const formLogin = document.getElementById("form-login");
  if (formLogin) {
    formLogin.addEventListener("submit", (e) => {
      e.preventDefault();
      let valid = true;

      const email = document.getElementById("login-email").value;
      const pass = document.getElementById("login-pass").value;
      const errEmail = document.getElementById("err-login-email");
      const errPass = document.getElementById("err-login-pass");

      errEmail.textContent = "";
      errPass.textContent = "";

      if (!isValidEmailDomain(email)) {
        errEmail.textContent = "Correo invalido. Solo dominios @duoc.cl, @profesor.duoc.cl o @gmail.com.";
        valid = false;
      }

      if (pass.length < 4 || pass.length > 10) {
        errPass.textContent = "La contraseña debe tener entre 4 y 10 caracteres.";
        valid = false;
      }

      if (valid) {
  alert("Inicio de sesion exitoso.");
  
  if (email === "admin@duoc.cl") {
    window.location.href = "admin.html"; 
  } else {
    window.location.href = "index.html"; 
  }
  }
    });
  }

  // 3. Validación Registro
  const formReg = document.getElementById("form-registro");
  if (formReg) {
    formReg.addEventListener("submit", (e) => {
      e.preventDefault();
      let valid = true;

      const run = document.getElementById("reg-run").value.trim();
      const nombre = document.getElementById("reg-nombre").value.trim();
      const email = document.getElementById("reg-email").value.trim();
      const pass = document.getElementById("reg-pass").value;
      const passConf = document.getElementById("reg-pass-confirm").value;

      if (run.length < 7 || run.length > 9) {
        document.getElementById("err-reg-run").textContent = "RUN debe tener entre 7 y 9 caracteres sin puntos ni guion.";
        valid = false;
      } else {
        document.getElementById("err-reg-run").textContent = "";
      }

      if (nombre.length === 0 || nombre.length > 150) {
        document.getElementById("err-reg-nombre").textContent = "Nombre requerido (max 150 caracteres).";
        valid = false;
      } else {
        document.getElementById("err-reg-nombre").textContent = "";
      }

      if (!isValidEmailDomain(email)) {
        document.getElementById("err-reg-email").textContent = "Correo invalido para el registro.";
        valid = false;
      } else {
        document.getElementById("err-reg-email").textContent = "";
      }

      if (pass.length < 4 || pass.length > 10) {
        document.getElementById("err-reg-pass").textContent = "Contraseña de 4 a 10 caracteres.";
        valid = false;
      } else if (pass !== passConf) {
        document.getElementById("err-reg-pass-confirm").textContent = "Las contraseñas no coinciden.";
        valid = false;
      } else {
        document.getElementById("err-reg-pass").textContent = "";
        document.getElementById("err-reg-pass-confirm").textContent = "";
      }

      if (valid) {
        alert("Usuario registrado correctamente.");
        window.location.href = "login.html";
      }
    });
  }

  // 4. Validacion Contacto
  const formContact = document.getElementById("form-contacto");
  if (formContact) {
    formContact.addEventListener("submit", (e) => {
      e.preventDefault();
      let valid = true;

      const nombre = document.getElementById("cont-nombre").value.trim();
      const email = document.getElementById("cont-email").value.trim();
      const mensaje = document.getElementById("cont-mensaje").value.trim();

      if (!nombre || nombre.length > 100) {
        document.getElementById("err-cont-nombre").textContent = "El nombre es obligatorio (max 100 caracteres).";
        valid = false;
      } else {
        document.getElementById("err-cont-nombre").textContent = "";
      }

      if (!isValidEmailDomain(email)) {
        document.getElementById("err-cont-email").textContent = "Correo invalido para contacto.";
        valid = false;
      } else {
        document.getElementById("err-cont-email").textContent = "";
      }

      if (!mensaje || mensaje.length > 500) {
        document.getElementById("err-cont-mensaje").textContent = "El mensaje es obligatorio (max 500 caracteres).";
        valid = false;
      } else {
        document.getElementById("err-cont-mensaje").textContent = "";
      }

      if (valid) {
        alert("Mensaje enviado exitosamente.");
        formContact.reset();
      }
    });
  }
});