// --- BASE DE DATOS SIMULADA (LocalStorage) ---
let dbProductos = JSON.parse(localStorage.getItem('admin_productos')) || [];
let dbUsuarios = JSON.parse(localStorage.getItem('admin_usuarios')) || [];

const regionesData = [
  { region: "Metropolitana", comunas: ["Santiago", "Puente Alto", "Providencia"] },
  { region: "Valparaíso", comunas: ["Valparaíso", "Viña del Mar"] }
];

// --- NAVEGACIÓN SINGLE PAGE ---
function showSection(sectionId, navElement = null) {
  document.querySelectorAll('.admin-section').forEach(sec => sec.classList.add('d-none'));
  document.getElementById(sectionId).classList.remove('d-none');
  
  if (navElement) {
    document.querySelectorAll('.admin-nav a').forEach(link => link.classList.remove('active'));
    navElement.classList.add('active');
  }

  if (sectionId === 'sec-productos') renderProductos();
  if (sectionId === 'sec-usuarios') renderUsuarios();
}

// --- RENDERIZADO DE TABLAS ---
function renderProductos() {
  const tbody = document.querySelector('#sec-productos tbody');
  tbody.innerHTML = '';
  dbProductos.forEach(p => {
    tbody.innerHTML += `
      <tr>
        <td>${p.codigo}</td>
        <td>${p.nombre}</td>
        <td>$${p.precio}</td>
        <td>${p.stock}</td>
        <td>${p.categoria}</td>
        <td><button class="btn" onclick="editarProducto('${p.codigo}')">Editar</button></td>
      </tr>`;
  });
}

function renderUsuarios() {
  const tbody = document.querySelector('#sec-usuarios tbody');
  tbody.innerHTML = '';
  dbUsuarios.forEach(u => {
    tbody.innerHTML += `
      <tr>
        <td>${u.run}</td>
        <td>${u.nombre} ${u.apellido}</td>
        <td>${u.correo}</td>
        <td>${u.tipo}</td>
        <td><button class="btn" onclick="editarUsuario('${u.run}')">Editar</button></td>
      </tr>`;
  });
}

// --- FUNCIONES DE EDICIÓN ---
function editarProducto(codigo) {
  const p = dbProductos.find(x => x.codigo === codigo);
  if (!p) return;
  document.getElementById('prod-edit-id').value = p.codigo;
  document.getElementById('prod-codigo').value = p.codigo;
  document.getElementById('prod-codigo').disabled = true; // No se edita el código
  document.getElementById('prod-nombre').value = p.nombre;
  document.getElementById('prod-desc').value = p.desc || '';
  document.getElementById('prod-precio').value = p.precio;
  document.getElementById('prod-stock').value = p.stock;
  document.getElementById('prod-stock-crit').value = p.stockCritico || '';
  document.getElementById('prod-categoria').value = p.categoria;
  
  document.querySelector('#sec-nuevo-producto h1').textContent = "EDITAR PRODUCTO";
  showSection('sec-nuevo-producto');
}

function editarUsuario(run) {
  const u = dbUsuarios.find(x => x.run === run);
  if (!u) return;
  document.getElementById('usu-edit-id').value = u.run;
  document.getElementById('usu-run').value = u.run;
  document.getElementById('usu-run').disabled = true;
  document.getElementById('usu-nombre').value = u.nombre;
  document.getElementById('usu-apellido').value = u.apellido;
  document.getElementById('usu-correo').value = u.correo;
  document.getElementById('usu-fecha').value = u.fechaNac || '';
  document.getElementById('usu-tipo').value = u.tipo;
  document.getElementById('usu-region').value = u.region;
  
  // Disparar evento para cargar comunas
  document.getElementById('usu-region').dispatchEvent(new Event('change'));
  document.getElementById('usu-comuna').value = u.comuna;
  document.getElementById('usu-direccion').value = u.direccion;

  document.querySelector('#sec-nuevo-usuario h1').textContent = "EDITAR USUARIO";
  showSection('sec-nuevo-usuario');
}

// --- VALIDACIONES Y GUARDADO ---
document.addEventListener("DOMContentLoaded", () => {
  
  // Cargar Select de Regiones
  const selRegion = document.getElementById('usu-region');
  const selComuna = document.getElementById('usu-comuna');
  if (selRegion) {
    regionesData.forEach(r => selRegion.innerHTML += `<option value="${r.region}">${r.region}</option>`);
    selRegion.addEventListener('change', (e) => {
      selComuna.innerHTML = '<option value="">Seleccione...</option>';
      const reg = regionesData.find(x => x.region === e.target.value);
      if (reg) reg.comunas.forEach(c => selComuna.innerHTML += `<option value="${c}">${c}</option>`);
    });
  }

  // Guardar Producto
  const formProd = document.getElementById("form-admin-producto");
  if (formProd) {
    formProd.addEventListener("submit", (e) => {
      e.preventDefault();
      let valid = true;

      const editId = document.getElementById('prod-edit-id').value;
      const codigo = document.getElementById("prod-codigo").value.trim();
      const nombre = document.getElementById("prod-nombre").value.trim();
      const desc = document.getElementById("prod-desc").value.trim();
      const precio = parseFloat(document.getElementById("prod-precio").value);
      const stock = parseFloat(document.getElementById("prod-stock").value);
      const stockCrit = document.getElementById("prod-stock-crit").value;
      const categoria = document.getElementById("prod-categoria").value;

      if (codigo.length < 3) { document.getElementById("err-prod-codigo").textContent = "Mín 3 chars"; valid = false; } else { document.getElementById("err-prod-codigo").textContent = ""; }
      if (nombre.length === 0 || nombre.length > 100) { document.getElementById("err-prod-nombre").textContent = "Req. (Máx 100)"; valid = false; } else { document.getElementById("err-prod-nombre").textContent = ""; }
      if (desc.length > 500) { document.getElementById("err-prod-desc").textContent = "Máx 500 chars"; valid = false; } else { document.getElementById("err-prod-desc").textContent = ""; }
      if (isNaN(precio) || precio < 0) { document.getElementById("err-prod-precio").textContent = "Req. (Mín 0)"; valid = false; } else { document.getElementById("err-prod-precio").textContent = ""; }
      if (isNaN(stock) || stock < 0 || !Number.isInteger(stock)) { document.getElementById("err-prod-stock").textContent = "Req. (Entero mín 0)"; valid = false; } else { document.getElementById("err-prod-stock").textContent = ""; }
      
      if (stockCrit !== "" && (isNaN(stockCrit) || stockCrit < 0 || !Number.isInteger(Number(stockCrit)))) {
        document.getElementById("err-prod-stock-crit").textContent = "Opcional (Entero mín 0)"; valid = false; 
      } else { document.getElementById("err-prod-stock-crit").textContent = ""; }

      if (categoria === "") { document.getElementById("err-prod-categoria").textContent = "Req."; valid = false; } else { document.getElementById("err-prod-categoria").textContent = ""; }

      if (valid) {
        const nuevoProd = { codigo, nombre, desc, precio, stock, stockCritico: stockCrit, categoria };
        
        if (editId) {
          const index = dbProductos.findIndex(x => x.codigo === editId);
          dbProductos[index] = nuevoProd;
        } else {
          if (dbProductos.some(x => x.codigo === codigo)) return alert("El código ya existe");
          dbProductos.push(nuevoProd);
        }

        localStorage.setItem('admin_productos', JSON.stringify(dbProductos));
        alert("Producto guardado.");
        formProd.reset();
        document.getElementById('prod-codigo').disabled = false;
        document.getElementById('prod-edit-id').value = '';
        showSection('sec-productos');
      }
    });
  }

  // Guardar Usuario
  const formUsu = document.getElementById("form-admin-usuario");
  if (formUsu) {
    formUsu.addEventListener("submit", (e) => {
      e.preventDefault();
      let valid = true;

      const editId = document.getElementById('usu-edit-id').value;
      const run = document.getElementById("usu-run").value.trim();
      const nombre = document.getElementById("usu-nombre").value.trim();
      const apellido = document.getElementById("usu-apellido").value.trim();
      const correo = document.getElementById("usu-correo").value.trim();
      const fechaNac = document.getElementById("usu-fecha").value;
      const tipo = document.getElementById("usu-tipo").value;
      const region = document.getElementById("usu-region").value;
      const comuna = document.getElementById("usu-comuna").value;
      const direccion = document.getElementById("usu-direccion").value.trim();

      if (run.length < 7 || run.length > 9 || run.includes(".") || run.includes("-")) { document.getElementById("err-usu-run").textContent = "Inválido"; valid = false; } else { document.getElementById("err-usu-run").textContent = ""; }
      if (nombre.length === 0 || nombre.length > 50) { document.getElementById("err-usu-nombre").textContent = "Req. (Máx 50)"; valid = false; } else { document.getElementById("err-usu-nombre").textContent = ""; }
      if (apellido.length === 0 || apellido.length > 100) { document.getElementById("err-usu-apellido").textContent = "Req. (Máx 100)"; valid = false; } else { document.getElementById("err-usu-apellido").textContent = ""; }
      if (!/^[a-zA-Z0-9._%+-]+@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/.test(correo)) { document.getElementById("err-usu-correo").textContent = "Dominio inválido"; valid = false; } else { document.getElementById("err-usu-correo").textContent = ""; }
      if (tipo === "") { document.getElementById("err-usu-tipo").textContent = "Req."; valid = false; } else { document.getElementById("err-usu-tipo").textContent = ""; }
      if (direccion.length === 0 || direccion.length > 300) { document.getElementById("err-usu-direccion").textContent = "Req. (Máx 300)"; valid = false; } else { document.getElementById("err-usu-direccion").textContent = ""; }

      if (valid) {
        const nuevoUsu = { run, nombre, apellido, correo, fechaNac, tipo, region, comuna, direccion };
        
        if (editId) {
          const index = dbUsuarios.findIndex(x => x.run === editId);
          dbUsuarios[index] = nuevoUsu;
        } else {
          if (dbUsuarios.some(x => x.run === run)) return alert("El RUN ya existe");
          dbUsuarios.push(nuevoUsu);
        }

        localStorage.setItem('admin_usuarios', JSON.stringify(dbUsuarios));
        alert("Usuario guardado.");
        formUsu.reset();
        document.getElementById('usu-run').disabled = false;
        document.getElementById('usu-edit-id').value = '';
        showSection('sec-usuarios');
      }
    });
  }

  // Inicializar tablas si estamos en esas secciones
  renderProductos();
  renderUsuarios();
});